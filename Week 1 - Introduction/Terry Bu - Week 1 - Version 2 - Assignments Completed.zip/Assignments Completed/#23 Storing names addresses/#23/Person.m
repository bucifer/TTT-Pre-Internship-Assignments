//
//  Person.m
//  #23
//
//  Created by Aditya Narayan on 9/5/14.
//  Copyright (c) 2014 NM. All rights reserved.
//

#import "Person.h"

@implementation Person

@end
