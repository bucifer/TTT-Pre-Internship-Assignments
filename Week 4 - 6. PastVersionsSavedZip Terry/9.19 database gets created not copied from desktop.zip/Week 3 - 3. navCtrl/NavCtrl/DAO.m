//
//  DAO.m
//  NavCtrl
//
//  Created by Aditya Narayan on 9/16/14.
//  Copyright (c) 2014 Aditya Narayan. All rights reserved.
//

#import "DAO.h"


@implementation DAO

sqlite3 *navctrlDB;
NSString *dbPathString;

- (id)init {
    
    Company *apple = [[Company alloc]initWithName:@"Apple" Image:@"apple.png" symbol:@"AAPL" ];
    Company *samsung = [[Company alloc]initWithName:@"Samsung" Image:@"samsung.png" symbol:@"SSNLF"];
    Company *htc = [[Company alloc]initWithName:@"HTC" Image:@"htc.jpg" symbol:@"htcxf"];
    Company *motorola = [[Company alloc]initWithName: @"Motorola" Image: @"motorola.gif" symbol:@"MSI"];

    self.companies = [[NSMutableArray alloc]
                      initWithObjects:
                      apple, samsung, htc, motorola, nil];
    
    Company *apple1 = self.companies[0];
    //Put product objects into the products array for the company
    Product *ipad = [[Product alloc]initWithName:@"iPad" Image:@"ipad.png" url:@"https://www.apple.com/ipad/"];
    Product *ipod_touch = [[Product alloc]initWithName:@"iPod Touch" Image:@"ipod_touch.png" url:@"http://www.apple.com/ipod-touch"];
    Product *iphone = [[Product alloc]initWithName:@"iPhone" Image:@"iphone.png" url:@"https://www.apple.com/iphone/"];
    apple1.products = [[NSMutableArray alloc]
                       initWithObjects:
                       ipad, ipod_touch, iphone, nil];
    
    
    Company *samsung2 = self.companies[1];
    //Put product objects into the products array for the company
    Product *s4 = [[Product alloc]initWithName:@"Galaxy S4" Image:@"galaxy_s4.png" url:@"http://www.samsung.com/global/microsite/galaxys4/"];
    Product *note = [[Product alloc]initWithName:@"Galaxy Note" Image:@"galaxy_note.jpg_256" url:@"http://www.samsung.com/global/microsite/galaxynote/note/index.html"];
    Product *tab = [[Product alloc]initWithName:@"Galaxy Tab" Image:@"galaxy_tab.jpg" url:@"http://www.samsung.com/us/mobile/galaxy-tab/"];
    samsung2.products = [[NSMutableArray alloc]
                         initWithObjects: s4, note, tab, nil];
    
    Company *htc3 = self.companies[2];
    Product *m8 = [[Product alloc]initWithName:@"HTC One M8" Image:@"htc_m8.jpg" url:@"http://www.htc.com/us/smartphones/htc-one-m8/"];
    Product *remix = [[Product alloc]initWithName:@"HTC One Remix" Image:@"htc_one_remix.png" url:@"http://www.htc.com/us/smartphones/htc-one-remix/"];
    Product *flyer = [[Product alloc]initWithName:@"HTC Flyer" Image:@"htc_flyer.png" url:@"http://www.amazon.com/HTC-Flyer-Android-Tablet-16/dp/B0053RJ3F8"];
    htc3.products = [[NSMutableArray alloc]
                     initWithObjects: m8, remix, flyer, nil];
    
    Company *motorola4 = self.companies[3];
    Product *moto_x = [[Product alloc]initWithName:@"Moto X" Image:@"moto_x.png" url:@"https://www.motorola.com/us/motomaker?pid=FLEXR2"];
    Product *moto_g = [[Product alloc]initWithName:@"Moto G" Image:@"moto_g.jpg" url:@"http://www.motorola.com/us/moto-g-pdp-1/Moto-G-(1st-Gen.)/moto-g-pdp.html"];
    Product *moto_360 = [[Product alloc]initWithName:@"Moto 360" Image:@"moto_360.png" url:@"http://www.androidcentral.com/moto-360"];
    motorola4.products = [[NSMutableArray alloc]
                          initWithObjects: moto_x, moto_g, moto_360, nil];
    

    [self createOrOpenDB];
    [self readCompanyFromDatabase];
    [self readProductsFromDatabase];
    
    return self;
}

//There's gonna be a whole bunch of columns
//Company Table
//Product Table
//Download sqlite browser, use that interface to enter in all the column data

-(void)createOrOpenDB
{
    char *error;
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [path objectAtIndex:0];
    dbPathString = [docPath stringByAppendingPathComponent:@"terry.sqlite3"];
    const char *dbPath = [dbPathString UTF8String];

    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if (![fileManager fileExistsAtPath:dbPathString]) {
        //if we don't find something at the datapath, we create a new database.
        if (sqlite3_open(dbPath, &navctrlDB)== SQLITE_OK) {
            //Fill the database with Company and Products data
            const char *sql_stmt_company = "CREATE TABLE IF NOT EXISTS Company (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, IMAGE TEXT, stockSymbol TEXT)";
            const char *sql_stmt_product = "CREATE TABLE IF NOT EXISTS Product (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, IMAGE TEXT, URL TEXT)";
            if ( (sqlite3_exec(navctrlDB, sql_stmt_company, NULL, NULL, &error) == SQLITE_OK) &&             sqlite3_exec(navctrlDB, sql_stmt_product, NULL, NULL, &error) == SQLITE_OK)
            {
                NSLog(@"Company table created");
                NSLog(@"Product table created");
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Create" message:@"Created Company and Product tables because we couldn't find db at path" delegate:self cancelButtonTitle:@"Close" otherButtonTitles:nil];
                [alert show];
            }
            
            for (int i=0; i < self.companies.count; i++) {
                Company* selectedCompany = self.companies[i];
                NSString *insertStmt = [NSString stringWithFormat:
                                        @"INSERT INTO COMPANY (name, image, stockSymbol) VALUES ('%s', '%s', '%s')",
                                        [selectedCompany.name UTF8String],
                                        [selectedCompany.image UTF8String],
                                        [selectedCompany.stockSymbol UTF8String]
                                        ];
                const char *insert_stmt = [insertStmt UTF8String];
                if (sqlite3_exec(navctrlDB, insert_stmt, NULL, NULL, &error) == SQLITE_OK) {
                    NSLog(@"Company Data added to DB");
                }
                else {
                    NSLog(@"Couldn't execute Company insert statement");
                    NSLog(@"Database Error Message : %s", sqlite3_errmsg(navctrlDB));
                }
                
                for (int j=0; j < selectedCompany.products.count; j++) {
                    Product* selectedProduct = selectedCompany.products[j];
                    NSString *insertStmt2 = [NSString stringWithFormat:
                                             @"INSERT INTO PRODUCT (name, image, url) VALUES ('%s', '%s', '%s')",
                                             [selectedProduct.name UTF8String],
                                             [selectedProduct.image UTF8String],
                                             [selectedProduct.url UTF8String]
                                             ];
                    const char *insert_stmt2 = [insertStmt2 UTF8String];
                    if (sqlite3_exec(navctrlDB, insert_stmt2, NULL, NULL, &error) == SQLITE_OK) {
                        NSLog(@"Product Data added to DB");
                    }
                    else {
                        NSLog(@"Couldn't execute Product insert statement");
                        NSLog(@"Database Error Message : %s", sqlite3_errmsg(navctrlDB));
                    }
                }
            }
            
            
            sqlite3_close(navctrlDB);
        }
        else NSLog(@"couldn't open db");
    }
    else {
        //But if we do find something already existing, then we just open it
        NSLog(@"We found an existing db file at your dbPathString");
    }
  }

- (void) readCompanyFromDatabase {
    sqlite3_stmt *statement ;
    if (sqlite3_open([dbPathString UTF8String], &navctrlDB)==SQLITE_OK) {
        [self.companies removeAllObjects];
        NSString *querySQL = [NSString stringWithFormat:@"SELECT * FROM COMPANY"];
        const char *query_sql = [querySQL UTF8String];
        if (sqlite3_prepare(navctrlDB, query_sql, -1, &statement, NULL) == SQLITE_OK)
        {
            while (sqlite3_step(statement)== SQLITE_ROW)
            {
                NSString *name = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
                NSString *image = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
                NSString *stockSymbol = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 3)];
                Company *company = [[Company alloc]init];
                company.name = name;
                company.image = image;
                company.stockSymbol = stockSymbol;
                company.products = [[NSMutableArray alloc] init];
                [self.companies addObject:company];
            }
        }
    }
    NSLog(@"We read from the Company Table");
}

- (void) readProductsFromDatabase {
    //put it in different statement
    sqlite3_stmt *statement ;
    if (sqlite3_open([dbPathString UTF8String], &navctrlDB)==SQLITE_OK) {
    NSString *querySQL = [NSString stringWithFormat:@"SELECT * FROM PRODUCT"];
    const char *query_sql = [querySQL UTF8String];
        if (sqlite3_prepare(navctrlDB, query_sql, -1, &statement, NULL) == SQLITE_OK)
        {
            while (sqlite3_step(statement)== SQLITE_ROW)
            {
                NSString *name = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 1)];
                NSString *image = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 2)];
                NSString *url = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 3)];
                Product *product = [[Product alloc]init];
                product.name = name;
                product.image = image;
                product.url = url;
                NSString* Products_Company = [[NSString alloc]initWithUTF8String:(const char *)sqlite3_column_text(statement, 4)];
                ////loop through every company in your companies array,
                ////with every row in the Product table, and if it equals a certain company, then you put it in the companies.product array
                for (int i=0; i < self.companies.count; i++) {
                    Company* selectedCompany = self.companies[i];
                    if ([selectedCompany.name isEqualToString: Products_Company]) {
                        NSLog(@"found a match at %@ with %@", selectedCompany.name, product.name);
                        [selectedCompany.products addObject: product];
                    }
                }
            }
        }
    }
    NSLog(@"We read from the Product Table");
}




- (void) deleteProduct: (Product*) product {
    NSLog(@"deleteProduct method called");
    [self.selectedCompany.products removeObject:product];
    //you send the delete SQL query
    [self deleteData:[NSString stringWithFormat:@"DELETE FROM PRODUCT WHERE NAME IS '%s'", [product.name UTF8String]]];
    NSLog(@"Product %@ Delete successful", product.name);
}

-(void)deleteData:(NSString *)deleteQuery {
    sqlite3_stmt *statement ;
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [path objectAtIndex:0];
    dbPathString = [docPath stringByAppendingPathComponent:@"terry.sqlite3"];
    const char *dbPath = [dbPathString UTF8String];
    if (sqlite3_open(dbPath, &navctrlDB)==SQLITE_OK) {
            if (sqlite3_prepare_v2(navctrlDB, [deleteQuery UTF8String], -1, &statement, NULL)==SQLITE_OK) {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete" message:@"Product Deleted" delegate:self cancelButtonTitle:@"Close" otherButtonTitles:nil];
                [alert show];
                if (sqlite3_step(statement) == SQLITE_DONE) {
                    NSLog(@"Sqlite3 step done");
                }
            }
            else {
                NSLog(@"Database Error Message : %s", sqlite3_errmsg(navctrlDB));
            }
        sqlite3_finalize(statement);
        sqlite3_close(navctrlDB);
    }
}


@end