//
//  DAO.h
//  NavCtrl
//
//  Created by Aditya Narayan on 9/16/14.
//  Copyright (c) 2014 Aditya Narayan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Company.h"
#import "Product.h"
#import "sqlite3.h"

@interface DAO : NSObject

@property (nonatomic, strong) NSMutableArray* companies;
@property (nonatomic, strong) Company* selectedCompany;

- (id)init;
- (void)deleteProduct: (Product *) product;
- (void) readCompanyFromDatabase;
- (void) readProductsFromDatabase;

@end
